// ─── CSS Variable Definitions for Light + Dark Themes ────────────────────────
// Applied to :root via ThemeProvider. Uses Paper + Ink palette.

export const lightVars: Record<string, string> = {
  // Paper surfaces
  '--paper': '#FAF7F1',
  '--paper2': '#F4EFE5',
  '--ink': '#141414',
  '--ink2': '#2B2B2B',
  '--muted-ink': '#525252',
  '--subtle-ink': '#6F6F6F',

  // Borders
  '--border': 'rgba(20,20,20,0.16)',
  '--border-strong': 'rgba(20,20,20,0.26)',

  // Surfaces
  '--surface': 'rgba(255,255,255,0.72)',
  '--surface-solid': '#FFFFFF',
  '--surface-alt': 'rgba(250,247,241,0.75)',

  // Brand
  '--primary': '#2D6A4F',
  '--primary-hover': '#1B4D38',
  '--primary-soft': 'rgba(45,106,79,0.12)',

  // Semantic
  '--success': '#40916C',
  '--success-soft': 'rgba(64,145,108,0.10)',
  '--warning': '#D97706',
  '--warning-soft': 'rgba(217,119,6,0.10)',
  '--danger': '#DC2626',
  '--danger-soft': 'rgba(220,38,38,0.10)',
  '--info': '#1F6FEB',
  '--info-soft': 'rgba(31,111,235,0.10)',

  // Focus
  '--focus-ring': '0 0 0 3px rgba(45,106,79,0.30)',
  '--link': '#2D6A4F',

  // Shadows (stacked-paper feel: soft shadow + highlight edge)
  '--shadow-sm': '0 1px 0 rgba(0,0,0,0.06), 0 6px 16px rgba(0,0,0,0.06)',
  '--shadow-md': '0 1px 0 rgba(0,0,0,0.08), 0 10px 24px rgba(0,0,0,0.08)',
  '--shadow-lg': '0 1px 0 rgba(0,0,0,0.10), 0 18px 40px rgba(0,0,0,0.10)',
  '--highlight-edge': 'inset 0 1px 0 rgba(255,255,255,0.70)',

  // Sketch effects
  '--sketch-outline-opacity': '0.22',
  '--paper-grain-opacity': '0.11',
  '--paper-fiber-opacity': '0.06',
  '--paper-contrast': '1.0',
  '--paper-noise-scale': '200',
  '--paper-drift-distance': '12px',
  '--paper-drift-duration': '14s',

  // Ink borders
  '--ink-border': 'rgba(20,20,20,0.22)',
  '--ink-border-strong': 'rgba(20,20,20,0.38)',
  '--sketch-wobble': '0.6px',
  '--sketch-rotate': '-0.15deg',

  // Marker highlight
  '--marker-color': 'rgba(45,106,79,0.10)',
  '--marker-blend': 'multiply',
  '--marker-opacity': '0.55',

  // Alias vars used in Layout + components
  '--text-primary': '#141414',
  '--text-secondary': '#525252',
  '--border-mid': 'rgba(20,20,20,0.20)',
  // Acid accent (highlight color for active states)
  '--acid': '#2D6A4F',
  '--acid-dim': 'rgba(45,106,79,0.10)',
  '--acid-mid': 'rgba(45,106,79,0.40)',
};

export const darkVars: Record<string, string> = {
  '--paper': '#0E0F12',
  '--paper2': '#12141A',
  '--ink': '#F5F5F5',
  '--ink2': '#E9E9E9',
  '--muted-ink': '#BDBDBD',
  '--subtle-ink': '#9B9B9B',

  '--border': 'rgba(245,245,245,0.14)',
  '--border-strong': 'rgba(245,245,245,0.22)',

  '--surface': 'rgba(18,20,26,0.72)',
  '--surface-solid': '#12141A',
  '--surface-alt': 'rgba(14,15,18,0.75)',

  '--primary': '#74C69D',
  '--primary-hover': '#95D5B2',
  '--primary-soft': 'rgba(116,198,157,0.14)',

  '--success': '#74C69D',
  '--success-soft': 'rgba(116,198,157,0.10)',
  '--warning': '#FBBF24',
  '--warning-soft': 'rgba(251,191,36,0.10)',
  '--danger': '#F87171',
  '--danger-soft': 'rgba(248,113,113,0.10)',
  '--info': '#6EA8FF',
  '--info-soft': 'rgba(110,168,255,0.14)',

  '--focus-ring': '0 0 0 3px rgba(116,198,157,0.30)',
  '--link': '#95D5B2',

  '--shadow-sm': '0 1px 0 rgba(0,0,0,0.20), 0 6px 16px rgba(0,0,0,0.25)',
  '--shadow-md': '0 1px 0 rgba(0,0,0,0.25), 0 10px 24px rgba(0,0,0,0.30)',
  '--shadow-lg': '0 1px 0 rgba(0,0,0,0.30), 0 18px 40px rgba(0,0,0,0.40)',
  '--highlight-edge': 'inset 0 1px 0 rgba(255,255,255,0.06)',

  '--sketch-outline-opacity': '0.18',
  '--paper-grain-opacity': '0.16',
  '--paper-fiber-opacity': '0.08',
  '--paper-contrast': '1.15',
  '--paper-noise-scale': '180',
  '--paper-drift-distance': '10px',
  '--paper-drift-duration': '16s',

  '--ink-border': 'rgba(245,245,245,0.16)',
  '--ink-border-strong': 'rgba(245,245,245,0.28)',
  '--sketch-wobble': '0.5px',
  '--sketch-rotate': '0.12deg',

  // Marker highlight
  '--marker-color': 'rgba(116,198,157,0.12)',
  '--marker-blend': 'soft-light',
  '--marker-opacity': '0.50',

  // Alias vars used in Layout + components
  '--text-primary': '#F5F5F5',
  '--text-secondary': '#BDBDBD',
  '--border-mid': 'rgba(245,245,245,0.18)',
  // Acid accent — bright mint in dark mode
  '--acid': '#74C69D',
  '--acid-dim': 'rgba(116,198,157,0.12)',
  '--acid-mid': 'rgba(116,198,157,0.40)',
};
