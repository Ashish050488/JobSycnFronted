export { default } from './FooterModern';
